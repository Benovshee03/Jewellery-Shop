import React from 'react'
import SerCss from '../Search/Search.module.css'
import Header from '../Header/Header'
export default function Search() {
  return (
    <section className={SerCss.search}><Header/></section>
  )
}
