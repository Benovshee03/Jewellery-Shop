import React from 'react'
import Header from '../Header/Header'
export default function Shop() {
  return (
    <div>
      <Header/>
    </div>
  )
}
