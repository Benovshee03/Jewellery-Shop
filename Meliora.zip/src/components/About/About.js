import React from 'react'
import AboCss from '../About/About.module.css'
import Header from '../Header/Header'
export default function About() {
  return (
    <div>
      <Header className={AboCss.head}/>
    </div>
  )
}
